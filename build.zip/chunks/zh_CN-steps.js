(window["webpackJsonpGUI"] = window["webpackJsonpGUI"] || []).push([["zh_CN-steps"],{

/***/ "./src/lib/libraries/decks/steps/add-effects.zh_CN.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/add-effects.zh_CN.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/db93767599eba837a46871720a47d148.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/add-variable.zh_CN.gif":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/add-variable.zh_CN.gif ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/efc0f24a3d0ebe9ccdfd7392058f8274.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-add-sound.zh_CN.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-add-sound.zh_CN.png ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8cfc79915028f43d481bd5ea8eafc9ed.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-change-color.zh_CN.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-change-color.zh_CN.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c56dfc57ba7eab324fed5cd72a0d92c9.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-jump.zh_CN.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-jump.zh_CN.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e559f3a36902c9285228b7e842e75dc6.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-move.zh_CN.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-move.zh_CN.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/cb0b3132e926a32505fbd25af018203c.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-say-something.zh_CN.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-say-something.zh_CN.png ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e3bb24700ae7a04d4e31b04ec67ce189.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/animate-char-talk.zh_CN.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/animate-char-talk.zh_CN.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c0878b928f59a5f14d0436a4748a8731.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/change-size.zh_CN.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/change-size.zh_CN.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c010daca9c3de0d95f304e3c64c120c0.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-change-score.zh_CN.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-change-score.zh_CN.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6bad8d2cf8533163b78c1312122e65e8.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-move-randomly.zh_CN.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-move-randomly.zh_CN.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e9b82f49559c7a78e7e57bd07b3edd45.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-play-sound.zh_CN.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-play-sound.zh_CN.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/92ce550a8e78c714b655580a03f37ddd.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-right-left.zh_CN.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-right-left.zh_CN.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f6fcd0d885c7e2a50ae71adccf92a99f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/chase-game-up-down.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/chase-game-up-down.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0a907e4555aebe1ddf4f650b73be0701.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-backdrop.zh_CN.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-backdrop.zh_CN.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/60ad32c07eeb04fa6c3ee68586572329.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-collect.zh_CN.png":
/*!************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-collect.zh_CN.png ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b1a1083af6320c24b608246af62ea202.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-glide.zh_CN.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-glide.zh_CN.png ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/db426166326d7895a3b09f3ac8040616.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-say.zh_CN.png":
/*!********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-say.zh_CN.png ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/31233f7f72ad06fc2244f4b19cb9eafe.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/cn-score.zh_CN.png":
/*!**********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/cn-score.zh_CN.png ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2dbfac58a99f6f1bbd66a23a6519ef10.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-01-say-something.zh_CN.png":
/*!*******************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-01-say-something.zh_CN.png ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ad74810a8379c9515a272888211921c4.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-02-animate.zh_CN.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-02-animate.zh_CN.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/aa5e1a2ea01301cb280d194cf72bac3f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.zh_CN.png":
/*!********************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.zh_CN.png ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/47aef1d83301e37025553b8b6982e3dd.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.zh_CN.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.zh_CN.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d2def3685a9cd9760e2869888f8c7ac0.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-07-jump.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-07-jump.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/49155458334f57d91193a2a347c23311.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.zh_CN.png":
/*!*******************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.zh_CN.png ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c9eb9a25b468d850aef34ad1bcf04d8f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.zh_CN.png":
/*!******************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.zh_CN.png ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/940eaee5fce37aa61ba5e6845c71d766.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.zh_CN.png":
/*!*********************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.zh_CN.png ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/40ed288c687ce245b74779771e16a9d1.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-flying-heart.zh_CN.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-flying-heart.zh_CN.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e8b661a1248933bed37b8800c4707f12.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-keep-score.zh_CN.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-keep-score.zh_CN.png ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5bf3ab9f0225769a36ad4b100f36c36f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-make-interactive.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-make-interactive.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/499a035b3b3b283ca4257fd26c725491.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-move-scenery.zh_CN.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-move-scenery.zh_CN.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/20e38f264d2f5995b1bae447598b0539.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-say-something.zh_CN.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-say-something.zh_CN.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/029f2533163e160cd39075be03c3db73.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/fly-switch-costume.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/fly-switch-costume.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ed839a3be50a57c11f4bf418803a5ed0.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/glide-around-back-and-forth.zh_CN.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/glide-around-back-and-forth.zh_CN.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8726263c2a7d24e22ecc662ed3ac70eb.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/glide-around-point.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/glide-around-point.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/71451233518e248c48c49aab303d6c00.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/hide-show.zh_CN.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/hide-show.zh_CN.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3954a4b8029afa558b84c060f7bb00ef.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-change-costumes.zh_CN.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-change-costumes.zh_CN.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2a3ba1084cca0bc13b8879eeb87c7640.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-choose-sound.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-choose-sound.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c2eb7ac401b3b0e25a6ac49405ae221e.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-click-green-flag.zh_CN.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-click-green-flag.zh_CN.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/51b13a62d6d738aa73dc275e968af83b.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-fly-around.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-fly-around.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ff611deb34bc9c097cb2ee3b16d35273.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-glide-to-point.zh_CN.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-glide-to-point.zh_CN.png ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7ae17c967f58ead058c188ed61eef847.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-grow-shrink.zh_CN.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-grow-shrink.zh_CN.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8f303509bdecaa73e6ff2a5fbb909b44.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-left-right.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-left-right.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6916af8b3aa2a83574676b63a0398876.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-record-a-sound.zh_CN.gif":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-record-a-sound.zh_CN.gif ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/86eb92c49b19cd572a1f7b36f1a41245.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-switch-backdrops.zh_CN.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-switch-backdrops.zh_CN.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9b6365fc68820b626eedbbb0060f6ead.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-type-what-you-want.zh_CN.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-type-what-you-want.zh_CN.png ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6ba7baed8c9edc87ff698926ff148685.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/imagine-up-down.zh_CN.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/imagine-up-down.zh_CN.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a2d061492bb48170f51a2f436b866a80.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-1-move.zh_CN.gif":
/*!**************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-1-move.zh_CN.gif ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/13bd951b42b52db5dd945271b02f98bb.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-2-say.zh_CN.gif":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-2-say.zh_CN.gif ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/32e097cfc94519493e9141415120a01a.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/intro-3-green-flag.zh_CN.gif":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/intro-3-green-flag.zh_CN.gif ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/65f4f96bd6a19bad3ec1d7534372ca48.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/move-arrow-keys-left-right.zh_CN.png":
/*!****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/move-arrow-keys-left-right.zh_CN.png ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/99b2b7361d516f2054b3bf8fbc015252.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/move-arrow-keys-up-down.zh_CN.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/move-arrow-keys-up-down.zh_CN.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d48ffeabb5073f52a22ba417438e8ff4.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-beat.zh_CN.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-beat.zh_CN.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b39c11251b02102b4a748769579793a4.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-beatbox.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-beatbox.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c328a73ec962d58e4553a5281ea07d7a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-make-song.zh_CN.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-make-song.zh_CN.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/67f61a6797faad9f0285517206b5ae27.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/music-play-sound.zh_CN.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/music-play-sound.zh_CN.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ca38c2c7658b44e276b09b04c440e3d2.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-change-color.zh_CN.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-change-color.zh_CN.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/35efc91659039e43f27f819a02a62632.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-grow.zh_CN.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-grow.zh_CN.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e1871903e042f246748298a915bee971.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-play-sound.zh_CN.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-play-sound.zh_CN.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/124ea6269c267395123ec9f1d2c5c587.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/name-spin.zh_CN.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/name-spin.zh_CN.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/381b8964610deccaeba07743f16e8953.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-add-code-to-ball.zh_CN.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-add-code-to-ball.zh_CN.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/fe4863d532234f0e9e15a3b51bb603eb.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-bounce-around.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-bounce-around.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/10ce7deabcbf4cccb17cca2621b94345.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-choose-score.zh_CN.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-choose-score.zh_CN.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6b92aada369c2fc9e71fb49064804850.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-game-over.zh_CN.png":
/*!****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-game-over.zh_CN.png ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d687b0a389aebcfb6110b83445a26e53.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-insert-change-score.zh_CN.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-insert-change-score.zh_CN.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e8b9e772b56ad2e3fa52aa9d47919880.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-move-the-paddle.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-move-the-paddle.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/48366697aa58756d9140e57957188c09.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pong-reset-score.zh_CN.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pong-reset-score.zh_CN.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e03a57a998de396f7a89ac47d0214769.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-change-color.zh_CN.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-change-color.zh_CN.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e0f359ce2f5ad60b443bdb153a076f56.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-change-score.zh_CN.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-change-score.zh_CN.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0f1feb8570cba8353844fc5747783d8f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-play-sound.zh_CN.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-play-sound.zh_CN.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/253b46780be9ceeb16dd390fa34f1822.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-random-position.zh_CN.png":
/*!**************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-random-position.zh_CN.png ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6aab923ab87e1998c1e7fefb2b3c9829.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/pop-game-reset-score.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/pop-game-reset-score.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/dde8aa58f32f9d0e50af951995bdca7f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-choose-sound.zh_CN.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-choose-sound.zh_CN.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a6b0f453205a7ff228cfba107ee5b97d.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-click-record.zh_CN.png":
/*!*****************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-click-record.zh_CN.png ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/175b4656e28f6827b1972260c13c1ceb.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.zh_CN.png":
/*!********************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.zh_CN.png ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/08d123fea3812a6f7d9b4d7eb946b1b1.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-press-record-button.zh_CN.png":
/*!************************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-press-record-button.zh_CN.png ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b1042e3dc7977193ae4dffa54728a84b.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.zh_CN.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.zh_CN.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/58d87881bfa7e0bacf6c1bf85ebd98ff.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-add-extension.zh_CN.gif":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-add-extension.zh_CN.gif ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8ae8345a94ca4f682244962e6dc57c21.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-change-color.zh_CN.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-change-color.zh_CN.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f36d5cbad056bc5dae54130fdef5658a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-grow-shrink.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-grow-shrink.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f572627b3caef731a440613e133041b2.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-move-around.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-move-around.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b825482327b3a30eff94a36296193d78.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-say-something.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-say-something.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ce6e50c9f7f1d7d4a4f51fd01993a2ce.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-set-voice.zh_CN.png":
/*!******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-set-voice.zh_CN.png ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8447a900a52e87d717ddeda4280434c1.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-song.zh_CN.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-song.zh_CN.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8f08a38f9e9878088a218ad02360e369.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/speech-spin.zh_CN.png":
/*!*************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/speech-spin.zh_CN.png ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/91e81a26f85822490d280f29736ccc8b.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/spin-point-in-direction.zh_CN.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/spin-point-in-direction.zh_CN.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c5a70a659d7400ca36c753f5ea7afd33.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/spin-turn.zh_CN.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/spin-turn.zh_CN.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c429a0c638d1138c1f0b6ddac3491bad.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-conversation.zh_CN.png":
/*!********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-conversation.zh_CN.png ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/37de3069a22757d8aa830b8632980f94.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-flip.zh_CN.gif":
/*!************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-flip.zh_CN.gif ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/30d93aa5f2b8455444e72d40206571bf.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-hide-character.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-hide-character.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b84d093ed85484282118fdb25ce3e3f9.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-say-something.zh_CN.png":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-say-something.zh_CN.png ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2001551c7cc77426db3bb692d9bb3c7a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-show-character.zh_CN.png":
/*!**********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-show-character.zh_CN.png ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/633ef8c7dee9f3eb793a73f5ef867e19.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/story-switch-backdrop.zh_CN.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/story-switch-backdrop.zh_CN.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a23892b230c6d987e43994efa487da0a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/switch-costumes.zh_CN.png":
/*!*****************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/switch-costumes.zh_CN.png ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3683e23b8be8e893db34f3430d3c0595.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-11-choose-sound.zh_CN.gif":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-11-choose-sound.zh_CN.gif ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f3e8aa205c0cf65ba99922ce1f3fc94e.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-12-dance-moves.zh_CN.png":
/*!************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-12-dance-moves.zh_CN.png ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2ca979d09b271f95782a44beecd7e94e.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-13-ask-and-answer.zh_CN.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-13-ask-and-answer.zh_CN.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5a931b14b2d580d278cc65be8822a77a.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-3-say-something.zh_CN.png":
/*!*************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-3-say-something.zh_CN.png ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/bf01dc918ea2dcb213fee7dad6e48245.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-5-switch-backdrop.zh_CN.png":
/*!***************************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-5-switch-backdrop.zh_CN.png ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ee57a2d2ee8660a1e8c6a4a66bbc802f.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-7-move-around.zh_CN.png":
/*!***********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-7-move-around.zh_CN.png ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b064ac23094b192d4e68a8eee99e7bf9.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/talking-9-animate.zh_CN.png":
/*!*******************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/talking-9-animate.zh_CN.png ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9905d7791a40b5238b05a398692c2ab9.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-add-extension.zh_CN.gif":
/*!*********************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-add-extension.zh_CN.gif ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/042a4888fd5737d866bf70a7811f14b2.gif";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-animate.zh_CN.png":
/*!***************************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-animate.zh_CN.png ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6b73c1dd54524c22aa4695fc442cadaa.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-pet.zh_CN.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-pet.zh_CN.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/07cde53e4081efae25eaa9518ddc0f32.png";

/***/ }),

/***/ "./src/lib/libraries/decks/steps/video-pop.zh_CN.png":
/*!***********************************************************!*\
  !*** ./src/lib/libraries/decks/steps/video-pop.zh_CN.png ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/47144cdb9c8e168e8013458020a28448.png";

/***/ }),

/***/ "./src/lib/libraries/decks/zh_CN-steps.js":
/*!************************************************!*\
  !*** ./src/lib/libraries/decks/zh_CN-steps.js ***!
  \************************************************/
/*! exports provided: zhCnImages */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "zhCnImages", function() { return zhCnImages; });
/* harmony import */ var _steps_intro_1_move_zh_CN_gif__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./steps/intro-1-move.zh_CN.gif */ "./src/lib/libraries/decks/steps/intro-1-move.zh_CN.gif");
/* harmony import */ var _steps_intro_1_move_zh_CN_gif__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_1_move_zh_CN_gif__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _steps_intro_2_say_zh_CN_gif__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./steps/intro-2-say.zh_CN.gif */ "./src/lib/libraries/decks/steps/intro-2-say.zh_CN.gif");
/* harmony import */ var _steps_intro_2_say_zh_CN_gif__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_2_say_zh_CN_gif__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _steps_intro_3_green_flag_zh_CN_gif__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./steps/intro-3-green-flag.zh_CN.gif */ "./src/lib/libraries/decks/steps/intro-3-green-flag.zh_CN.gif");
/* harmony import */ var _steps_intro_3_green_flag_zh_CN_gif__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_3_green_flag_zh_CN_gif__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _steps_speech_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./steps/speech-add-extension.zh_CN.gif */ "./src/lib/libraries/decks/steps/speech-add-extension.zh_CN.gif");
/* harmony import */ var _steps_speech_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _steps_speech_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./steps/speech-say-something.zh_CN.png */ "./src/lib/libraries/decks/steps/speech-say-something.zh_CN.png");
/* harmony import */ var _steps_speech_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _steps_speech_set_voice_zh_CN_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./steps/speech-set-voice.zh_CN.png */ "./src/lib/libraries/decks/steps/speech-set-voice.zh_CN.png");
/* harmony import */ var _steps_speech_set_voice_zh_CN_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_set_voice_zh_CN_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _steps_speech_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./steps/speech-move-around.zh_CN.png */ "./src/lib/libraries/decks/steps/speech-move-around.zh_CN.png");
/* harmony import */ var _steps_speech_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./steps/pick-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/pick-backdrop.LTR.gif");
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./steps/speech-add-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/speech-add-sprite.LTR.gif");
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _steps_speech_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./steps/speech-song.zh_CN.png */ "./src/lib/libraries/decks/steps/speech-song.zh_CN.png");
/* harmony import */ var _steps_speech_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _steps_speech_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./steps/speech-change-color.zh_CN.png */ "./src/lib/libraries/decks/steps/speech-change-color.zh_CN.png");
/* harmony import */ var _steps_speech_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _steps_speech_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./steps/speech-spin.zh_CN.png */ "./src/lib/libraries/decks/steps/speech-spin.zh_CN.png");
/* harmony import */ var _steps_speech_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _steps_speech_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./steps/speech-grow-shrink.zh_CN.png */ "./src/lib/libraries/decks/steps/speech-grow-shrink.zh_CN.png");
/* harmony import */ var _steps_speech_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./steps/cn-show-character.LTR.gif */ "./src/lib/libraries/decks/steps/cn-show-character.LTR.gif");
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _steps_cn_say_zh_CN_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./steps/cn-say.zh_CN.png */ "./src/lib/libraries/decks/steps/cn-say.zh_CN.png");
/* harmony import */ var _steps_cn_say_zh_CN_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_say_zh_CN_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _steps_cn_glide_zh_CN_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./steps/cn-glide.zh_CN.png */ "./src/lib/libraries/decks/steps/cn-glide.zh_CN.png");
/* harmony import */ var _steps_cn_glide_zh_CN_png__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_glide_zh_CN_png__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./steps/cn-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/cn-pick-sprite.LTR.gif");
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _steps_cn_collect_zh_CN_png__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./steps/cn-collect.zh_CN.png */ "./src/lib/libraries/decks/steps/cn-collect.zh_CN.png");
/* harmony import */ var _steps_cn_collect_zh_CN_png__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_collect_zh_CN_png__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./steps/add-variable.zh_CN.gif */ "./src/lib/libraries/decks/steps/add-variable.zh_CN.gif");
/* harmony import */ var _steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _steps_cn_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./steps/cn-score.zh_CN.png */ "./src/lib/libraries/decks/steps/cn-score.zh_CN.png");
/* harmony import */ var _steps_cn_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _steps_cn_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./steps/cn-backdrop.zh_CN.png */ "./src/lib/libraries/decks/steps/cn-backdrop.zh_CN.png");
/* harmony import */ var _steps_cn_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./steps/add-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/add-sprite.LTR.gif");
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./steps/name-pick-letter.LTR.gif */ "./src/lib/libraries/decks/steps/name-pick-letter.LTR.gif");
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _steps_name_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./steps/name-play-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/name-play-sound.zh_CN.png");
/* harmony import */ var _steps_name_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_steps_name_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./steps/name-pick-letter2.LTR.gif */ "./src/lib/libraries/decks/steps/name-pick-letter2.LTR.gif");
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _steps_name_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./steps/name-change-color.zh_CN.png */ "./src/lib/libraries/decks/steps/name-change-color.zh_CN.png");
/* harmony import */ var _steps_name_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_steps_name_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _steps_name_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./steps/name-spin.zh_CN.png */ "./src/lib/libraries/decks/steps/name-spin.zh_CN.png");
/* harmony import */ var _steps_name_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_steps_name_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _steps_name_grow_zh_CN_png__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./steps/name-grow.zh_CN.png */ "./src/lib/libraries/decks/steps/name-grow.zh_CN.png");
/* harmony import */ var _steps_name_grow_zh_CN_png__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_steps_name_grow_zh_CN_png__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./steps/music-pick-instrument.LTR.gif */ "./src/lib/libraries/decks/steps/music-pick-instrument.LTR.gif");
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _steps_music_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./steps/music-play-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/music-play-sound.zh_CN.png");
/* harmony import */ var _steps_music_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_steps_music_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _steps_music_make_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./steps/music-make-song.zh_CN.png */ "./src/lib/libraries/decks/steps/music-make-song.zh_CN.png");
/* harmony import */ var _steps_music_make_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _steps_music_make_beat_zh_CN_png__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./steps/music-make-beat.zh_CN.png */ "./src/lib/libraries/decks/steps/music-make-beat.zh_CN.png");
/* harmony import */ var _steps_music_make_beat_zh_CN_png__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beat_zh_CN_png__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _steps_music_make_beatbox_zh_CN_png__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./steps/music-make-beatbox.zh_CN.png */ "./src/lib/libraries/decks/steps/music-make-beatbox.zh_CN.png");
/* harmony import */ var _steps_music_make_beatbox_zh_CN_png__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beatbox_zh_CN_png__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./steps/chase-game-add-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-backdrop.LTR.gif");
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./steps/chase-game-add-sprite1.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-sprite1.LTR.gif");
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var _steps_chase_game_right_left_zh_CN_png__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./steps/chase-game-right-left.zh_CN.png */ "./src/lib/libraries/decks/steps/chase-game-right-left.zh_CN.png");
/* harmony import */ var _steps_chase_game_right_left_zh_CN_png__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_right_left_zh_CN_png__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _steps_chase_game_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./steps/chase-game-up-down.zh_CN.png */ "./src/lib/libraries/decks/steps/chase-game-up-down.zh_CN.png");
/* harmony import */ var _steps_chase_game_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./steps/chase-game-add-sprite2.LTR.gif */ "./src/lib/libraries/decks/steps/chase-game-add-sprite2.LTR.gif");
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var _steps_chase_game_move_randomly_zh_CN_png__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./steps/chase-game-move-randomly.zh_CN.png */ "./src/lib/libraries/decks/steps/chase-game-move-randomly.zh_CN.png");
/* harmony import */ var _steps_chase_game_move_randomly_zh_CN_png__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_move_randomly_zh_CN_png__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var _steps_chase_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./steps/chase-game-play-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/chase-game-play-sound.zh_CN.png");
/* harmony import */ var _steps_chase_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var _steps_chase_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./steps/chase-game-change-score.zh_CN.png */ "./src/lib/libraries/decks/steps/chase-game-change-score.zh_CN.png");
/* harmony import */ var _steps_chase_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./steps/pop-game-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/pop-game-pick-sprite.LTR.gif");
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var _steps_pop_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./steps/pop-game-play-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/pop-game-play-sound.zh_CN.png");
/* harmony import */ var _steps_pop_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var _steps_pop_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./steps/pop-game-change-score.zh_CN.png */ "./src/lib/libraries/decks/steps/pop-game-change-score.zh_CN.png");
/* harmony import */ var _steps_pop_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var _steps_pop_game_random_position_zh_CN_png__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./steps/pop-game-random-position.zh_CN.png */ "./src/lib/libraries/decks/steps/pop-game-random-position.zh_CN.png");
/* harmony import */ var _steps_pop_game_random_position_zh_CN_png__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_random_position_zh_CN_png__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var _steps_pop_game_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./steps/pop-game-change-color.zh_CN.png */ "./src/lib/libraries/decks/steps/pop-game-change-color.zh_CN.png");
/* harmony import */ var _steps_pop_game_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var _steps_pop_game_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./steps/pop-game-reset-score.zh_CN.png */ "./src/lib/libraries/decks/steps/pop-game-reset-score.zh_CN.png");
/* harmony import */ var _steps_pop_game_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./steps/animate-char-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/animate-char-pick-sprite.LTR.gif");
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var _steps_animate_char_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./steps/animate-char-say-something.zh_CN.png */ "./src/lib/libraries/decks/steps/animate-char-say-something.zh_CN.png");
/* harmony import */ var _steps_animate_char_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var _steps_animate_char_add_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(/*! ./steps/animate-char-add-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/animate-char-add-sound.zh_CN.png");
/* harmony import */ var _steps_animate_char_add_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_add_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var _steps_animate_char_talk_zh_CN_png__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(/*! ./steps/animate-char-talk.zh_CN.png */ "./src/lib/libraries/decks/steps/animate-char-talk.zh_CN.png");
/* harmony import */ var _steps_animate_char_talk_zh_CN_png__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_talk_zh_CN_png__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var _steps_animate_char_move_zh_CN_png__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(/*! ./steps/animate-char-move.zh_CN.png */ "./src/lib/libraries/decks/steps/animate-char-move.zh_CN.png");
/* harmony import */ var _steps_animate_char_move_zh_CN_png__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_move_zh_CN_png__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var _steps_animate_char_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(/*! ./steps/animate-char-jump.zh_CN.png */ "./src/lib/libraries/decks/steps/animate-char-jump.zh_CN.png");
/* harmony import */ var _steps_animate_char_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_52___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_52__);
/* harmony import */ var _steps_animate_char_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(/*! ./steps/animate-char-change-color.zh_CN.png */ "./src/lib/libraries/decks/steps/animate-char-change-color.zh_CN.png");
/* harmony import */ var _steps_animate_char_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_53___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_53__);
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(/*! ./steps/story-pick-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-backdrop.LTR.gif");
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__);
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(/*! ./steps/story-pick-sprite.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-sprite.LTR.gif");
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__);
/* harmony import */ var _steps_story_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(/*! ./steps/story-say-something.zh_CN.png */ "./src/lib/libraries/decks/steps/story-say-something.zh_CN.png");
/* harmony import */ var _steps_story_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(_steps_story_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(/*! ./steps/story-pick-sprite2.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-sprite2.LTR.gif");
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var _steps_story_flip_zh_CN_gif__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(/*! ./steps/story-flip.zh_CN.gif */ "./src/lib/libraries/decks/steps/story-flip.zh_CN.gif");
/* harmony import */ var _steps_story_flip_zh_CN_gif__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(_steps_story_flip_zh_CN_gif__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var _steps_story_conversation_zh_CN_png__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(/*! ./steps/story-conversation.zh_CN.png */ "./src/lib/libraries/decks/steps/story-conversation.zh_CN.png");
/* harmony import */ var _steps_story_conversation_zh_CN_png__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(_steps_story_conversation_zh_CN_png__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(/*! ./steps/story-pick-backdrop2.LTR.gif */ "./src/lib/libraries/decks/steps/story-pick-backdrop2.LTR.gif");
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__);
/* harmony import */ var _steps_story_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(/*! ./steps/story-switch-backdrop.zh_CN.png */ "./src/lib/libraries/decks/steps/story-switch-backdrop.zh_CN.png");
/* harmony import */ var _steps_story_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_61___default = /*#__PURE__*/__webpack_require__.n(_steps_story_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_61__);
/* harmony import */ var _steps_story_hide_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(/*! ./steps/story-hide-character.zh_CN.png */ "./src/lib/libraries/decks/steps/story-hide-character.zh_CN.png");
/* harmony import */ var _steps_story_hide_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_62___default = /*#__PURE__*/__webpack_require__.n(_steps_story_hide_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_62__);
/* harmony import */ var _steps_story_show_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(/*! ./steps/story-show-character.zh_CN.png */ "./src/lib/libraries/decks/steps/story-show-character.zh_CN.png");
/* harmony import */ var _steps_story_show_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_63___default = /*#__PURE__*/__webpack_require__.n(_steps_story_show_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_63__);
/* harmony import */ var _steps_video_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(/*! ./steps/video-add-extension.zh_CN.gif */ "./src/lib/libraries/decks/steps/video-add-extension.zh_CN.gif");
/* harmony import */ var _steps_video_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_64___default = /*#__PURE__*/__webpack_require__.n(_steps_video_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_64__);
/* harmony import */ var _steps_video_pet_zh_CN_png__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(/*! ./steps/video-pet.zh_CN.png */ "./src/lib/libraries/decks/steps/video-pet.zh_CN.png");
/* harmony import */ var _steps_video_pet_zh_CN_png__WEBPACK_IMPORTED_MODULE_65___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pet_zh_CN_png__WEBPACK_IMPORTED_MODULE_65__);
/* harmony import */ var _steps_video_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(/*! ./steps/video-animate.zh_CN.png */ "./src/lib/libraries/decks/steps/video-animate.zh_CN.png");
/* harmony import */ var _steps_video_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_66___default = /*#__PURE__*/__webpack_require__.n(_steps_video_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_66__);
/* harmony import */ var _steps_video_pop_zh_CN_png__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(/*! ./steps/video-pop.zh_CN.png */ "./src/lib/libraries/decks/steps/video-pop.zh_CN.png");
/* harmony import */ var _steps_video_pop_zh_CN_png__WEBPACK_IMPORTED_MODULE_67___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pop_zh_CN_png__WEBPACK_IMPORTED_MODULE_67__);
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(/*! ./steps/fly-choose-backdrop.LTR.gif */ "./src/lib/libraries/decks/steps/fly-choose-backdrop.LTR.gif");
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__);
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(/*! ./steps/fly-choose-character.LTR.png */ "./src/lib/libraries/decks/steps/fly-choose-character.LTR.png");
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__);
/* harmony import */ var _steps_fly_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(/*! ./steps/fly-say-something.zh_CN.png */ "./src/lib/libraries/decks/steps/fly-say-something.zh_CN.png");
/* harmony import */ var _steps_fly_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_70___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_70__);
/* harmony import */ var _steps_fly_make_interactive_zh_CN_png__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(/*! ./steps/fly-make-interactive.zh_CN.png */ "./src/lib/libraries/decks/steps/fly-make-interactive.zh_CN.png");
/* harmony import */ var _steps_fly_make_interactive_zh_CN_png__WEBPACK_IMPORTED_MODULE_71___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_make_interactive_zh_CN_png__WEBPACK_IMPORTED_MODULE_71__);
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(/*! ./steps/fly-object-to-collect.LTR.png */ "./src/lib/libraries/decks/steps/fly-object-to-collect.LTR.png");
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__);
/* harmony import */ var _steps_fly_flying_heart_zh_CN_png__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(/*! ./steps/fly-flying-heart.zh_CN.png */ "./src/lib/libraries/decks/steps/fly-flying-heart.zh_CN.png");
/* harmony import */ var _steps_fly_flying_heart_zh_CN_png__WEBPACK_IMPORTED_MODULE_73___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_flying_heart_zh_CN_png__WEBPACK_IMPORTED_MODULE_73__);
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(/*! ./steps/fly-select-flyer.LTR.png */ "./src/lib/libraries/decks/steps/fly-select-flyer.LTR.png");
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__);
/* harmony import */ var _steps_fly_keep_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(/*! ./steps/fly-keep-score.zh_CN.png */ "./src/lib/libraries/decks/steps/fly-keep-score.zh_CN.png");
/* harmony import */ var _steps_fly_keep_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_75___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_keep_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_75__);
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(/*! ./steps/fly-choose-scenery.LTR.gif */ "./src/lib/libraries/decks/steps/fly-choose-scenery.LTR.gif");
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__);
/* harmony import */ var _steps_fly_move_scenery_zh_CN_png__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(/*! ./steps/fly-move-scenery.zh_CN.png */ "./src/lib/libraries/decks/steps/fly-move-scenery.zh_CN.png");
/* harmony import */ var _steps_fly_move_scenery_zh_CN_png__WEBPACK_IMPORTED_MODULE_77___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_move_scenery_zh_CN_png__WEBPACK_IMPORTED_MODULE_77__);
/* harmony import */ var _steps_fly_switch_costume_zh_CN_png__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(/*! ./steps/fly-switch-costume.zh_CN.png */ "./src/lib/libraries/decks/steps/fly-switch-costume.zh_CN.png");
/* harmony import */ var _steps_fly_switch_costume_zh_CN_png__WEBPACK_IMPORTED_MODULE_78___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_switch_costume_zh_CN_png__WEBPACK_IMPORTED_MODULE_78__);
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(/*! ./steps/pong-add-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/pong-add-backdrop.LTR.png");
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__);
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__ = __webpack_require__(/*! ./steps/pong-add-ball-sprite.LTR.png */ "./src/lib/libraries/decks/steps/pong-add-ball-sprite.LTR.png");
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__);
/* harmony import */ var _steps_pong_bounce_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_81__ = __webpack_require__(/*! ./steps/pong-bounce-around.zh_CN.png */ "./src/lib/libraries/decks/steps/pong-bounce-around.zh_CN.png");
/* harmony import */ var _steps_pong_bounce_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_81___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_bounce_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_81__);
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__ = __webpack_require__(/*! ./steps/pong-add-a-paddle.LTR.gif */ "./src/lib/libraries/decks/steps/pong-add-a-paddle.LTR.gif");
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__);
/* harmony import */ var _steps_pong_move_the_paddle_zh_CN_png__WEBPACK_IMPORTED_MODULE_83__ = __webpack_require__(/*! ./steps/pong-move-the-paddle.zh_CN.png */ "./src/lib/libraries/decks/steps/pong-move-the-paddle.zh_CN.png");
/* harmony import */ var _steps_pong_move_the_paddle_zh_CN_png__WEBPACK_IMPORTED_MODULE_83___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_move_the_paddle_zh_CN_png__WEBPACK_IMPORTED_MODULE_83__);
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__ = __webpack_require__(/*! ./steps/pong-select-ball.LTR.png */ "./src/lib/libraries/decks/steps/pong-select-ball.LTR.png");
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__);
/* harmony import */ var _steps_pong_add_code_to_ball_zh_CN_png__WEBPACK_IMPORTED_MODULE_85__ = __webpack_require__(/*! ./steps/pong-add-code-to-ball.zh_CN.png */ "./src/lib/libraries/decks/steps/pong-add-code-to-ball.zh_CN.png");
/* harmony import */ var _steps_pong_add_code_to_ball_zh_CN_png__WEBPACK_IMPORTED_MODULE_85___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_code_to_ball_zh_CN_png__WEBPACK_IMPORTED_MODULE_85__);
/* harmony import */ var _steps_pong_choose_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_86__ = __webpack_require__(/*! ./steps/pong-choose-score.zh_CN.png */ "./src/lib/libraries/decks/steps/pong-choose-score.zh_CN.png");
/* harmony import */ var _steps_pong_choose_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_86___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_choose_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_86__);
/* harmony import */ var _steps_pong_insert_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_87__ = __webpack_require__(/*! ./steps/pong-insert-change-score.zh_CN.png */ "./src/lib/libraries/decks/steps/pong-insert-change-score.zh_CN.png");
/* harmony import */ var _steps_pong_insert_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_87___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_insert_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_87__);
/* harmony import */ var _steps_pong_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_88__ = __webpack_require__(/*! ./steps/pong-reset-score.zh_CN.png */ "./src/lib/libraries/decks/steps/pong-reset-score.zh_CN.png");
/* harmony import */ var _steps_pong_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_88___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_88__);
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__ = __webpack_require__(/*! ./steps/pong-add-line.LTR.gif */ "./src/lib/libraries/decks/steps/pong-add-line.LTR.gif");
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__);
/* harmony import */ var _steps_pong_game_over_zh_CN_png__WEBPACK_IMPORTED_MODULE_90__ = __webpack_require__(/*! ./steps/pong-game-over.zh_CN.png */ "./src/lib/libraries/decks/steps/pong-game-over.zh_CN.png");
/* harmony import */ var _steps_pong_game_over_zh_CN_png__WEBPACK_IMPORTED_MODULE_90___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_game_over_zh_CN_png__WEBPACK_IMPORTED_MODULE_90__);
/* harmony import */ var _steps_imagine_type_what_you_want_zh_CN_png__WEBPACK_IMPORTED_MODULE_91__ = __webpack_require__(/*! ./steps/imagine-type-what-you-want.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-type-what-you-want.zh_CN.png");
/* harmony import */ var _steps_imagine_type_what_you_want_zh_CN_png__WEBPACK_IMPORTED_MODULE_91___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_type_what_you_want_zh_CN_png__WEBPACK_IMPORTED_MODULE_91__);
/* harmony import */ var _steps_imagine_click_green_flag_zh_CN_png__WEBPACK_IMPORTED_MODULE_92__ = __webpack_require__(/*! ./steps/imagine-click-green-flag.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-click-green-flag.zh_CN.png");
/* harmony import */ var _steps_imagine_click_green_flag_zh_CN_png__WEBPACK_IMPORTED_MODULE_92___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_click_green_flag_zh_CN_png__WEBPACK_IMPORTED_MODULE_92__);
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__ = __webpack_require__(/*! ./steps/imagine-choose-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-backdrop.LTR.png");
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__);
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__ = __webpack_require__(/*! ./steps/imagine-choose-any-sprite.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-any-sprite.LTR.png");
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__);
/* harmony import */ var _steps_imagine_fly_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_95__ = __webpack_require__(/*! ./steps/imagine-fly-around.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-fly-around.zh_CN.png");
/* harmony import */ var _steps_imagine_fly_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_95___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_fly_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_95__);
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__ = __webpack_require__(/*! ./steps/imagine-choose-another-sprite.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-another-sprite.LTR.png");
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__);
/* harmony import */ var _steps_imagine_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_97__ = __webpack_require__(/*! ./steps/imagine-left-right.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-left-right.zh_CN.png");
/* harmony import */ var _steps_imagine_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_97___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_97__);
/* harmony import */ var _steps_imagine_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_98__ = __webpack_require__(/*! ./steps/imagine-up-down.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-up-down.zh_CN.png");
/* harmony import */ var _steps_imagine_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_98___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_98__);
/* harmony import */ var _steps_imagine_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_99__ = __webpack_require__(/*! ./steps/imagine-change-costumes.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-change-costumes.zh_CN.png");
/* harmony import */ var _steps_imagine_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_99___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_99__);
/* harmony import */ var _steps_imagine_glide_to_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_100__ = __webpack_require__(/*! ./steps/imagine-glide-to-point.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-glide-to-point.zh_CN.png");
/* harmony import */ var _steps_imagine_glide_to_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_100___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_glide_to_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_100__);
/* harmony import */ var _steps_imagine_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_101__ = __webpack_require__(/*! ./steps/imagine-grow-shrink.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-grow-shrink.zh_CN.png");
/* harmony import */ var _steps_imagine_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_101___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_101__);
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__ = __webpack_require__(/*! ./steps/imagine-choose-another-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/imagine-choose-another-backdrop.LTR.png");
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__);
/* harmony import */ var _steps_imagine_switch_backdrops_zh_CN_png__WEBPACK_IMPORTED_MODULE_103__ = __webpack_require__(/*! ./steps/imagine-switch-backdrops.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-switch-backdrops.zh_CN.png");
/* harmony import */ var _steps_imagine_switch_backdrops_zh_CN_png__WEBPACK_IMPORTED_MODULE_103___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_switch_backdrops_zh_CN_png__WEBPACK_IMPORTED_MODULE_103__);
/* harmony import */ var _steps_imagine_record_a_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_104__ = __webpack_require__(/*! ./steps/imagine-record-a-sound.zh_CN.gif */ "./src/lib/libraries/decks/steps/imagine-record-a-sound.zh_CN.gif");
/* harmony import */ var _steps_imagine_record_a_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_104___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_record_a_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_104__);
/* harmony import */ var _steps_imagine_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_105__ = __webpack_require__(/*! ./steps/imagine-choose-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/imagine-choose-sound.zh_CN.png");
/* harmony import */ var _steps_imagine_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_105___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_105__);
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__ = __webpack_require__(/*! ./steps/add-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/add-backdrop.LTR.png");
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default = /*#__PURE__*/__webpack_require__.n(_steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__);
/* harmony import */ var _steps_add_effects_zh_CN_png__WEBPACK_IMPORTED_MODULE_107__ = __webpack_require__(/*! ./steps/add-effects.zh_CN.png */ "./src/lib/libraries/decks/steps/add-effects.zh_CN.png");
/* harmony import */ var _steps_add_effects_zh_CN_png__WEBPACK_IMPORTED_MODULE_107___default = /*#__PURE__*/__webpack_require__.n(_steps_add_effects_zh_CN_png__WEBPACK_IMPORTED_MODULE_107__);
/* harmony import */ var _steps_hide_show_zh_CN_png__WEBPACK_IMPORTED_MODULE_108__ = __webpack_require__(/*! ./steps/hide-show.zh_CN.png */ "./src/lib/libraries/decks/steps/hide-show.zh_CN.png");
/* harmony import */ var _steps_hide_show_zh_CN_png__WEBPACK_IMPORTED_MODULE_108___default = /*#__PURE__*/__webpack_require__.n(_steps_hide_show_zh_CN_png__WEBPACK_IMPORTED_MODULE_108__);
/* harmony import */ var _steps_switch_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_109__ = __webpack_require__(/*! ./steps/switch-costumes.zh_CN.png */ "./src/lib/libraries/decks/steps/switch-costumes.zh_CN.png");
/* harmony import */ var _steps_switch_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_109___default = /*#__PURE__*/__webpack_require__.n(_steps_switch_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_109__);
/* harmony import */ var _steps_change_size_zh_CN_png__WEBPACK_IMPORTED_MODULE_110__ = __webpack_require__(/*! ./steps/change-size.zh_CN.png */ "./src/lib/libraries/decks/steps/change-size.zh_CN.png");
/* harmony import */ var _steps_change_size_zh_CN_png__WEBPACK_IMPORTED_MODULE_110___default = /*#__PURE__*/__webpack_require__.n(_steps_change_size_zh_CN_png__WEBPACK_IMPORTED_MODULE_110__);
/* harmony import */ var _steps_spin_turn_zh_CN_png__WEBPACK_IMPORTED_MODULE_111__ = __webpack_require__(/*! ./steps/spin-turn.zh_CN.png */ "./src/lib/libraries/decks/steps/spin-turn.zh_CN.png");
/* harmony import */ var _steps_spin_turn_zh_CN_png__WEBPACK_IMPORTED_MODULE_111___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_turn_zh_CN_png__WEBPACK_IMPORTED_MODULE_111__);
/* harmony import */ var _steps_spin_point_in_direction_zh_CN_png__WEBPACK_IMPORTED_MODULE_112__ = __webpack_require__(/*! ./steps/spin-point-in-direction.zh_CN.png */ "./src/lib/libraries/decks/steps/spin-point-in-direction.zh_CN.png");
/* harmony import */ var _steps_spin_point_in_direction_zh_CN_png__WEBPACK_IMPORTED_MODULE_112___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_point_in_direction_zh_CN_png__WEBPACK_IMPORTED_MODULE_112__);
/* harmony import */ var _steps_record_a_sound_sounds_tab_zh_CN_png__WEBPACK_IMPORTED_MODULE_113__ = __webpack_require__(/*! ./steps/record-a-sound-sounds-tab.zh_CN.png */ "./src/lib/libraries/decks/steps/record-a-sound-sounds-tab.zh_CN.png");
/* harmony import */ var _steps_record_a_sound_sounds_tab_zh_CN_png__WEBPACK_IMPORTED_MODULE_113___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_sounds_tab_zh_CN_png__WEBPACK_IMPORTED_MODULE_113__);
/* harmony import */ var _steps_record_a_sound_click_record_zh_CN_png__WEBPACK_IMPORTED_MODULE_114__ = __webpack_require__(/*! ./steps/record-a-sound-click-record.zh_CN.png */ "./src/lib/libraries/decks/steps/record-a-sound-click-record.zh_CN.png");
/* harmony import */ var _steps_record_a_sound_click_record_zh_CN_png__WEBPACK_IMPORTED_MODULE_114___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_click_record_zh_CN_png__WEBPACK_IMPORTED_MODULE_114__);
/* harmony import */ var _steps_record_a_sound_press_record_button_zh_CN_png__WEBPACK_IMPORTED_MODULE_115__ = __webpack_require__(/*! ./steps/record-a-sound-press-record-button.zh_CN.png */ "./src/lib/libraries/decks/steps/record-a-sound-press-record-button.zh_CN.png");
/* harmony import */ var _steps_record_a_sound_press_record_button_zh_CN_png__WEBPACK_IMPORTED_MODULE_115___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_press_record_button_zh_CN_png__WEBPACK_IMPORTED_MODULE_115__);
/* harmony import */ var _steps_record_a_sound_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_116__ = __webpack_require__(/*! ./steps/record-a-sound-choose-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/record-a-sound-choose-sound.zh_CN.png");
/* harmony import */ var _steps_record_a_sound_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_116___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_116__);
/* harmony import */ var _steps_record_a_sound_play_your_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_117__ = __webpack_require__(/*! ./steps/record-a-sound-play-your-sound.zh_CN.png */ "./src/lib/libraries/decks/steps/record-a-sound-play-your-sound.zh_CN.png");
/* harmony import */ var _steps_record_a_sound_play_your_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_117___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_play_your_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_117__);
/* harmony import */ var _steps_move_arrow_keys_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_118__ = __webpack_require__(/*! ./steps/move-arrow-keys-left-right.zh_CN.png */ "./src/lib/libraries/decks/steps/move-arrow-keys-left-right.zh_CN.png");
/* harmony import */ var _steps_move_arrow_keys_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_118___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_118__);
/* harmony import */ var _steps_move_arrow_keys_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_119__ = __webpack_require__(/*! ./steps/move-arrow-keys-up-down.zh_CN.png */ "./src/lib/libraries/decks/steps/move-arrow-keys-up-down.zh_CN.png");
/* harmony import */ var _steps_move_arrow_keys_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_119___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_119__);
/* harmony import */ var _steps_glide_around_back_and_forth_zh_CN_png__WEBPACK_IMPORTED_MODULE_120__ = __webpack_require__(/*! ./steps/glide-around-back-and-forth.zh_CN.png */ "./src/lib/libraries/decks/steps/glide-around-back-and-forth.zh_CN.png");
/* harmony import */ var _steps_glide_around_back_and_forth_zh_CN_png__WEBPACK_IMPORTED_MODULE_120___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_back_and_forth_zh_CN_png__WEBPACK_IMPORTED_MODULE_120__);
/* harmony import */ var _steps_glide_around_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_121__ = __webpack_require__(/*! ./steps/glide-around-point.zh_CN.png */ "./src/lib/libraries/decks/steps/glide-around-point.zh_CN.png");
/* harmony import */ var _steps_glide_around_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_121___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_121__);
/* harmony import */ var _steps_code_cartoon_01_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_122__ = __webpack_require__(/*! ./steps/code-cartoon-01-say-something.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-01-say-something.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_01_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_122___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_01_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_122__);
/* harmony import */ var _steps_code_cartoon_02_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_123__ = __webpack_require__(/*! ./steps/code-cartoon-02-animate.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-02-animate.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_02_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_123___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_02_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_123__);
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__ = __webpack_require__(/*! ./steps/code-cartoon-03-select-different-character.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-03-select-different-character.LTR.png");
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__);
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_zh_CN_png__WEBPACK_IMPORTED_MODULE_125__ = __webpack_require__(/*! ./steps/code-cartoon-04-use-minus-sign.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-04-use-minus-sign.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_zh_CN_png__WEBPACK_IMPORTED_MODULE_125___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_04_use_minus_sign_zh_CN_png__WEBPACK_IMPORTED_MODULE_125__);
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_126__ = __webpack_require__(/*! ./steps/code-cartoon-05-grow-shrink.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-05-grow-shrink.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_126___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_05_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_126__);
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__ = __webpack_require__(/*! ./steps/code-cartoon-06-select-another-different-character.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-06-select-another-different-character.LTR.png");
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__);
/* harmony import */ var _steps_code_cartoon_07_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_128__ = __webpack_require__(/*! ./steps/code-cartoon-07-jump.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-07-jump.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_07_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_128___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_07_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_128__);
/* harmony import */ var _steps_code_cartoon_08_change_scenes_zh_CN_png__WEBPACK_IMPORTED_MODULE_129__ = __webpack_require__(/*! ./steps/code-cartoon-08-change-scenes.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-08-change-scenes.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_08_change_scenes_zh_CN_png__WEBPACK_IMPORTED_MODULE_129___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_08_change_scenes_zh_CN_png__WEBPACK_IMPORTED_MODULE_129__);
/* harmony import */ var _steps_code_cartoon_09_glide_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_130__ = __webpack_require__(/*! ./steps/code-cartoon-09-glide-around.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-09-glide-around.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_09_glide_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_130___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_09_glide_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_130__);
/* harmony import */ var _steps_code_cartoon_10_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_131__ = __webpack_require__(/*! ./steps/code-cartoon-10-change-costumes.zh_CN.png */ "./src/lib/libraries/decks/steps/code-cartoon-10-change-costumes.zh_CN.png");
/* harmony import */ var _steps_code_cartoon_10_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_131___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_10_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_131__);
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__ = __webpack_require__(/*! ./steps/code-cartoon-11-choose-more-characters.LTR.png */ "./src/lib/libraries/decks/steps/code-cartoon-11-choose-more-characters.LTR.png");
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__);
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__ = __webpack_require__(/*! ./steps/talking-2-choose-sprite.LTR.png */ "./src/lib/libraries/decks/steps/talking-2-choose-sprite.LTR.png");
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__);
/* harmony import */ var _steps_talking_3_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_134__ = __webpack_require__(/*! ./steps/talking-3-say-something.zh_CN.png */ "./src/lib/libraries/decks/steps/talking-3-say-something.zh_CN.png");
/* harmony import */ var _steps_talking_3_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_134___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_3_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_134__);
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__ = __webpack_require__(/*! ./steps/talking-4-choose-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-4-choose-backdrop.LTR.png");
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__);
/* harmony import */ var _steps_talking_5_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_136__ = __webpack_require__(/*! ./steps/talking-5-switch-backdrop.zh_CN.png */ "./src/lib/libraries/decks/steps/talking-5-switch-backdrop.zh_CN.png");
/* harmony import */ var _steps_talking_5_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_136___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_5_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_136__);
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__ = __webpack_require__(/*! ./steps/talking-6-choose-another-sprite.LTR.png */ "./src/lib/libraries/decks/steps/talking-6-choose-another-sprite.LTR.png");
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__);
/* harmony import */ var _steps_talking_7_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_138__ = __webpack_require__(/*! ./steps/talking-7-move-around.zh_CN.png */ "./src/lib/libraries/decks/steps/talking-7-move-around.zh_CN.png");
/* harmony import */ var _steps_talking_7_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_138___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_7_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_138__);
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__ = __webpack_require__(/*! ./steps/talking-8-choose-another-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-8-choose-another-backdrop.LTR.png");
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__);
/* harmony import */ var _steps_talking_9_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_140__ = __webpack_require__(/*! ./steps/talking-9-animate.zh_CN.png */ "./src/lib/libraries/decks/steps/talking-9-animate.zh_CN.png");
/* harmony import */ var _steps_talking_9_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_140___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_9_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_140__);
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__ = __webpack_require__(/*! ./steps/talking-10-choose-third-backdrop.LTR.png */ "./src/lib/libraries/decks/steps/talking-10-choose-third-backdrop.LTR.png");
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__);
/* harmony import */ var _steps_talking_11_choose_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_142__ = __webpack_require__(/*! ./steps/talking-11-choose-sound.zh_CN.gif */ "./src/lib/libraries/decks/steps/talking-11-choose-sound.zh_CN.gif");
/* harmony import */ var _steps_talking_11_choose_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_142___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_11_choose_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_142__);
/* harmony import */ var _steps_talking_12_dance_moves_zh_CN_png__WEBPACK_IMPORTED_MODULE_143__ = __webpack_require__(/*! ./steps/talking-12-dance-moves.zh_CN.png */ "./src/lib/libraries/decks/steps/talking-12-dance-moves.zh_CN.png");
/* harmony import */ var _steps_talking_12_dance_moves_zh_CN_png__WEBPACK_IMPORTED_MODULE_143___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_12_dance_moves_zh_CN_png__WEBPACK_IMPORTED_MODULE_143__);
/* harmony import */ var _steps_talking_13_ask_and_answer_zh_CN_png__WEBPACK_IMPORTED_MODULE_144__ = __webpack_require__(/*! ./steps/talking-13-ask-and-answer.zh_CN.png */ "./src/lib/libraries/decks/steps/talking-13-ask-and-answer.zh_CN.png");
/* harmony import */ var _steps_talking_13_ask_and_answer_zh_CN_png__WEBPACK_IMPORTED_MODULE_144___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_13_ask_and_answer_zh_CN_png__WEBPACK_IMPORTED_MODULE_144__);
// Intro


 // Text to Speech










 // Cartoon Network








 // Add sprite

 // Animate a name






 // Make Music





 // Chase-Game









 // Clicker-Game (Pop Game)







 // Animate A Character








 // Tell A Story










 // Video Sensing




 // Make it Fly












 // Pong













 // Imagine a World















 // Add a Backdrop

 // Add Effects

 // Hide and Show

 // Switch Costumes

 // Change Size

 // Spin


 // Record a Sound





 // Use Arrow Keys


 // Glide Around


 // Code a Cartoon











 // Talking Tales














var zhCnImages = {
  // Intro
  introMove: _steps_intro_1_move_zh_CN_gif__WEBPACK_IMPORTED_MODULE_0___default.a,
  introSay: _steps_intro_2_say_zh_CN_gif__WEBPACK_IMPORTED_MODULE_1___default.a,
  introGreenFlag: _steps_intro_3_green_flag_zh_CN_gif__WEBPACK_IMPORTED_MODULE_2___default.a,
  // Text to Speech
  speechAddExtension: _steps_speech_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  speechSaySomething: _steps_speech_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_4___default.a,
  speechSetVoice: _steps_speech_set_voice_zh_CN_png__WEBPACK_IMPORTED_MODULE_5___default.a,
  speechMoveAround: _steps_speech_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  speechAddBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  speechAddSprite: _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default.a,
  speechSong: _steps_speech_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_9___default.a,
  speechChangeColor: _steps_speech_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_10___default.a,
  speechSpin: _steps_speech_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_11___default.a,
  speechGrowShrink: _steps_speech_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_12___default.a,
  // Cartoon Network
  cnShowCharacter: _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default.a,
  cnSay: _steps_cn_say_zh_CN_png__WEBPACK_IMPORTED_MODULE_14___default.a,
  cnGlide: _steps_cn_glide_zh_CN_png__WEBPACK_IMPORTED_MODULE_15___default.a,
  cnPickSprite: _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default.a,
  cnCollect: _steps_cn_collect_zh_CN_png__WEBPACK_IMPORTED_MODULE_17___default.a,
  cnVariable: _steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  cnScore: _steps_cn_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_19___default.a,
  cnBackdrop: _steps_cn_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_20___default.a,
  // Add sprite
  addSprite: _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default.a,
  // Animate a name
  namePickLetter: _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default.a,
  namePlaySound: _steps_name_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_23___default.a,
  namePickLetter2: _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default.a,
  nameChangeColor: _steps_name_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_25___default.a,
  nameSpin: _steps_name_spin_zh_CN_png__WEBPACK_IMPORTED_MODULE_26___default.a,
  nameGrow: _steps_name_grow_zh_CN_png__WEBPACK_IMPORTED_MODULE_27___default.a,
  // Make-Music
  musicPickInstrument: _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default.a,
  musicPlaySound: _steps_music_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_29___default.a,
  musicMakeSong: _steps_music_make_song_zh_CN_png__WEBPACK_IMPORTED_MODULE_30___default.a,
  musicMakeBeat: _steps_music_make_beat_zh_CN_png__WEBPACK_IMPORTED_MODULE_31___default.a,
  musicMakeBeatbox: _steps_music_make_beatbox_zh_CN_png__WEBPACK_IMPORTED_MODULE_32___default.a,
  // Chase-Game
  chaseGameAddBackdrop: _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default.a,
  chaseGameAddSprite1: _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default.a,
  chaseGameRightLeft: _steps_chase_game_right_left_zh_CN_png__WEBPACK_IMPORTED_MODULE_35___default.a,
  chaseGameUpDown: _steps_chase_game_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_36___default.a,
  chaseGameAddSprite2: _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default.a,
  chaseGameMoveRandomly: _steps_chase_game_move_randomly_zh_CN_png__WEBPACK_IMPORTED_MODULE_38___default.a,
  chaseGamePlaySound: _steps_chase_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_39___default.a,
  chaseGameAddVariable: _steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  chaseGameChangeScore: _steps_chase_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_40___default.a,
  // Make-A-Pop/Clicker Game
  popGamePickSprite: _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default.a,
  popGamePlaySound: _steps_pop_game_play_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_42___default.a,
  popGameAddScore: _steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  popGameChangeScore: _steps_pop_game_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_43___default.a,
  popGameRandomPosition: _steps_pop_game_random_position_zh_CN_png__WEBPACK_IMPORTED_MODULE_44___default.a,
  popGameChangeColor: _steps_pop_game_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_45___default.a,
  popGameResetScore: _steps_pop_game_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_46___default.a,
  // Animate A Character
  animateCharPickBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  animateCharPickSprite: _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default.a,
  animateCharSaySomething: _steps_animate_char_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_48___default.a,
  animateCharAddSound: _steps_animate_char_add_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_49___default.a,
  animateCharTalk: _steps_animate_char_talk_zh_CN_png__WEBPACK_IMPORTED_MODULE_50___default.a,
  animateCharMove: _steps_animate_char_move_zh_CN_png__WEBPACK_IMPORTED_MODULE_51___default.a,
  animateCharJump: _steps_animate_char_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_52___default.a,
  animateCharChangeColor: _steps_animate_char_change_color_zh_CN_png__WEBPACK_IMPORTED_MODULE_53___default.a,
  // Tell A Story
  storyPickBackdrop: _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default.a,
  storyPickSprite: _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default.a,
  storySaySomething: _steps_story_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_56___default.a,
  storyPickSprite2: _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default.a,
  storyFlip: _steps_story_flip_zh_CN_gif__WEBPACK_IMPORTED_MODULE_58___default.a,
  storyConversation: _steps_story_conversation_zh_CN_png__WEBPACK_IMPORTED_MODULE_59___default.a,
  storyPickBackdrop2: _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default.a,
  storySwitchBackdrop: _steps_story_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_61___default.a,
  storyHideCharacter: _steps_story_hide_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_62___default.a,
  storyShowCharacter: _steps_story_show_character_zh_CN_png__WEBPACK_IMPORTED_MODULE_63___default.a,
  // Video Sensing
  videoAddExtension: _steps_video_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_64___default.a,
  videoPet: _steps_video_pet_zh_CN_png__WEBPACK_IMPORTED_MODULE_65___default.a,
  videoAnimate: _steps_video_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_66___default.a,
  videoPop: _steps_video_pop_zh_CN_png__WEBPACK_IMPORTED_MODULE_67___default.a,
  // Make it Fly
  flyChooseBackdrop: _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default.a,
  flyChooseCharacter: _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default.a,
  flySaySomething: _steps_fly_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_70___default.a,
  flyMoveArrows: _steps_fly_make_interactive_zh_CN_png__WEBPACK_IMPORTED_MODULE_71___default.a,
  flyChooseObject: _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default.a,
  flyFlyingObject: _steps_fly_flying_heart_zh_CN_png__WEBPACK_IMPORTED_MODULE_73___default.a,
  flySelectFlyingSprite: _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default.a,
  flyAddScore: _steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  flyKeepScore: _steps_fly_keep_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_75___default.a,
  flyAddScenery: _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default.a,
  flyMoveScenery: _steps_fly_move_scenery_zh_CN_png__WEBPACK_IMPORTED_MODULE_77___default.a,
  flySwitchLooks: _steps_fly_switch_costume_zh_CN_png__WEBPACK_IMPORTED_MODULE_78___default.a,
  // Pong
  pongAddBackdrop: _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default.a,
  pongAddBallSprite: _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default.a,
  pongBounceAround: _steps_pong_bounce_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_81___default.a,
  pongAddPaddle: _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default.a,
  pongMoveThePaddle: _steps_pong_move_the_paddle_zh_CN_png__WEBPACK_IMPORTED_MODULE_83___default.a,
  pongSelectBallSprite: _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default.a,
  pongAddMoreCodeToBall: _steps_pong_add_code_to_ball_zh_CN_png__WEBPACK_IMPORTED_MODULE_85___default.a,
  pongAddAScore: _steps_add_variable_zh_CN_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  pongChooseScoreFromMenu: _steps_pong_choose_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_86___default.a,
  pongInsertChangeScoreBlock: _steps_pong_insert_change_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_87___default.a,
  pongResetScore: _steps_pong_reset_score_zh_CN_png__WEBPACK_IMPORTED_MODULE_88___default.a,
  pongAddLineSprite: _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default.a,
  pongGameOver: _steps_pong_game_over_zh_CN_png__WEBPACK_IMPORTED_MODULE_90___default.a,
  // Imagine a World
  imagineTypeWhatYouWant: _steps_imagine_type_what_you_want_zh_CN_png__WEBPACK_IMPORTED_MODULE_91___default.a,
  imagineClickGreenFlag: _steps_imagine_click_green_flag_zh_CN_png__WEBPACK_IMPORTED_MODULE_92___default.a,
  imagineChooseBackdrop: _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default.a,
  imagineChooseSprite: _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default.a,
  imagineFlyAround: _steps_imagine_fly_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_95___default.a,
  imagineChooseAnotherSprite: _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default.a,
  imagineLeftRight: _steps_imagine_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_97___default.a,
  imagineUpDown: _steps_imagine_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_98___default.a,
  imagineChangeCostumes: _steps_imagine_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_99___default.a,
  imagineGlideToPoint: _steps_imagine_glide_to_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_100___default.a,
  imagineGrowShrink: _steps_imagine_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_101___default.a,
  imagineChooseAnotherBackdrop: _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default.a,
  imagineSwitchBackdrops: _steps_imagine_switch_backdrops_zh_CN_png__WEBPACK_IMPORTED_MODULE_103___default.a,
  imagineRecordASound: _steps_imagine_record_a_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_104___default.a,
  imagineChooseSound: _steps_imagine_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_105___default.a,
  // Add a Backdrop
  addBackdrop: _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default.a,
  // Add Effects
  addEffects: _steps_add_effects_zh_CN_png__WEBPACK_IMPORTED_MODULE_107___default.a,
  // Hide and Show
  hideAndShow: _steps_hide_show_zh_CN_png__WEBPACK_IMPORTED_MODULE_108___default.a,
  // Switch Costumes
  switchCostumes: _steps_switch_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_109___default.a,
  // Change Size
  changeSize: _steps_change_size_zh_CN_png__WEBPACK_IMPORTED_MODULE_110___default.a,
  // Spin
  spinTurn: _steps_spin_turn_zh_CN_png__WEBPACK_IMPORTED_MODULE_111___default.a,
  spinPointInDirection: _steps_spin_point_in_direction_zh_CN_png__WEBPACK_IMPORTED_MODULE_112___default.a,
  // Record a Sound
  recordASoundSoundsTab: _steps_record_a_sound_sounds_tab_zh_CN_png__WEBPACK_IMPORTED_MODULE_113___default.a,
  recordASoundClickRecord: _steps_record_a_sound_click_record_zh_CN_png__WEBPACK_IMPORTED_MODULE_114___default.a,
  recordASoundPressRecordButton: _steps_record_a_sound_press_record_button_zh_CN_png__WEBPACK_IMPORTED_MODULE_115___default.a,
  recordASoundChooseSound: _steps_record_a_sound_choose_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_116___default.a,
  recordASoundPlayYourSound: _steps_record_a_sound_play_your_sound_zh_CN_png__WEBPACK_IMPORTED_MODULE_117___default.a,
  // Use Arrow Keys
  moveArrowKeysLeftRight: _steps_move_arrow_keys_left_right_zh_CN_png__WEBPACK_IMPORTED_MODULE_118___default.a,
  moveArrowKeysUpDown: _steps_move_arrow_keys_up_down_zh_CN_png__WEBPACK_IMPORTED_MODULE_119___default.a,
  // Glide Around
  glideAroundBackAndForth: _steps_glide_around_back_and_forth_zh_CN_png__WEBPACK_IMPORTED_MODULE_120___default.a,
  glideAroundPoint: _steps_glide_around_point_zh_CN_png__WEBPACK_IMPORTED_MODULE_121___default.a,
  // Code a Cartoon
  codeCartoonSaySomething: _steps_code_cartoon_01_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_122___default.a,
  codeCartoonAnimate: _steps_code_cartoon_02_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_123___default.a,
  codeCartoonSelectDifferentCharacter: _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default.a,
  codeCartoonUseMinusSign: _steps_code_cartoon_04_use_minus_sign_zh_CN_png__WEBPACK_IMPORTED_MODULE_125___default.a,
  codeCartoonGrowShrink: _steps_code_cartoon_05_grow_shrink_zh_CN_png__WEBPACK_IMPORTED_MODULE_126___default.a,
  codeCartoonSelectDifferentCharacter2: _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default.a,
  codeCartoonJump: _steps_code_cartoon_07_jump_zh_CN_png__WEBPACK_IMPORTED_MODULE_128___default.a,
  codeCartoonChangeScenes: _steps_code_cartoon_08_change_scenes_zh_CN_png__WEBPACK_IMPORTED_MODULE_129___default.a,
  codeCartoonGlideAround: _steps_code_cartoon_09_glide_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_130___default.a,
  codeCartoonChangeCostumes: _steps_code_cartoon_10_change_costumes_zh_CN_png__WEBPACK_IMPORTED_MODULE_131___default.a,
  codeCartoonChooseMoreCharacters: _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default.a,
  // Talking Tales
  talesAddExtension: _steps_speech_add_extension_zh_CN_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  talesChooseSprite: _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default.a,
  talesSaySomething: _steps_talking_3_say_something_zh_CN_png__WEBPACK_IMPORTED_MODULE_134___default.a,
  talesAskAnswer: _steps_talking_13_ask_and_answer_zh_CN_png__WEBPACK_IMPORTED_MODULE_144___default.a,
  talesChooseBackdrop: _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default.a,
  talesSwitchBackdrop: _steps_talking_5_switch_backdrop_zh_CN_png__WEBPACK_IMPORTED_MODULE_136___default.a,
  talesChooseAnotherSprite: _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default.a,
  talesMoveAround: _steps_talking_7_move_around_zh_CN_png__WEBPACK_IMPORTED_MODULE_138___default.a,
  talesChooseAnotherBackdrop: _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default.a,
  talesAnimateTalking: _steps_talking_9_animate_zh_CN_png__WEBPACK_IMPORTED_MODULE_140___default.a,
  talesChooseThirdBackdrop: _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default.a,
  talesChooseSound: _steps_talking_11_choose_sound_zh_CN_gif__WEBPACK_IMPORTED_MODULE_142___default.a,
  talesDanceMoves: _steps_talking_12_dance_moves_zh_CN_png__WEBPACK_IMPORTED_MODULE_143___default.a
};


/***/ })

}]);
//# sourceMappingURL=zh_CN-steps.js.map